from django.contrib import admin
from .models import FutaModel
admin.site.register(FutaModel)


# Register your models here.
