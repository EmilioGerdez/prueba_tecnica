from django.apps import AppConfig


class PdfManagerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pdf_manager'
